import { useEffect, useState } from 'react';
import { Coffee, Pause, Play, RotateCcw, Timer } from 'lucide-react';
import { dateKey } from './planner';

const modes = { study: { label: 'Study', seconds: 25 * 60 }, break: { label: 'Break', seconds: 5 * 60 } } as const;
type Mode = keyof typeof modes;
type TimerState = {
  mode: Mode;
  remaining: number;
  endsAt: number | null;
  completedOn: string;
  completed: number;
};

const timerKey = 'dayline.focus.v1';

function loadTimer(): TimerState {
  try {
    const saved = JSON.parse(localStorage.getItem(timerKey) ?? 'null') as TimerState | null;
    if (saved && (saved.mode === 'study' || saved.mode === 'break') && Number.isFinite(saved.remaining) &&
      (saved.endsAt === null || Number.isFinite(saved.endsAt)) && typeof saved.completedOn === 'string' &&
      Number.isInteger(saved.completed)) return saved;
  } catch {
    // The timer can still run if device storage is unavailable.
  }
  return { mode: 'study', remaining: modes.study.seconds, endsAt: null, completedOn: '', completed: 0 };
}

function secondsLeft(timer: TimerState, now: number) {
  return timer.endsAt === null ? timer.remaining : Math.max(0, Math.ceil((timer.endsAt - now) / 1000));
}

// Keep the timer in App so switching tabs does not interrupt a session.
export function useFocusTimer(today: string) {
  const [timer, setTimer] = useState(loadTimer);
  const [now, setNow] = useState(Date.now);
  const remaining = secondsLeft(timer, now);

  useEffect(() => {
    if (timer.endsAt === null) return;

    function tick() {
      const instant = Date.now();
      setNow(instant);
      setTimer(current => {
        if (current.endsAt === null || current.endsAt > instant) return current;
        if (current.mode === 'break') return { ...current, endsAt: null, remaining: 0 };
        const completedOn = dateKey(new Date(current.endsAt));
        const completed = (current.completedOn === completedOn ? current.completed : 0) + 1;
        return { ...current, endsAt: null, remaining: 0, completedOn, completed };
      });
    }
    tick();
    const interval = window.setInterval(tick, 1000);
    window.addEventListener('focus', tick);
    return () => {
      window.clearInterval(interval);
      window.removeEventListener('focus', tick);
    };
  }, [timer.endsAt]);

  useEffect(() => {
    try {
      localStorage.setItem(timerKey, JSON.stringify(timer));
    } catch {
      // The session remains available while Dayline is open.
    }
  }, [timer]);

  function changeMode(mode: Mode) {
    setTimer(current => ({ ...current, mode, remaining: modes[mode].seconds, endsAt: null }));
  }

  function toggle() {
    const instant = Date.now();
    setNow(instant);
    setTimer(current => {
      if (current.endsAt !== null && current.endsAt <= instant) return current;
      if (current.endsAt !== null) {
        return { ...current, remaining: secondsLeft(current, instant), endsAt: null };
      }
      const seconds = current.remaining || modes[current.mode].seconds;
      return { ...current, remaining: seconds, endsAt: instant + seconds * 1000 };
    });
  }

  return {
    mode: timer.mode,
    running: timer.endsAt !== null,
    remaining,
    completed: timer.completedOn === today ? timer.completed : 0,
    changeMode,
    toggle,
  };
}

export function Focus({ timer }: { timer: ReturnType<typeof useFocusTimer> }) {
  const minutes = Math.floor(timer.remaining / 60);
  const seconds = String(timer.remaining % 60).padStart(2, '0');
  const elapsed = 1 - timer.remaining / modes[timer.mode].seconds;
  const complete = timer.remaining === 0 && !timer.running;

  return <div className="focus-layout">
    <section className="focus-card" aria-label="Focus timer">
      <div className="segmented focus-modes" aria-label="Timer mode">
        <button aria-pressed={timer.mode === 'study'} onClick={() => timer.mode !== 'study' && timer.changeMode('study')}><Timer size={17}/> Study</button>
        <button aria-pressed={timer.mode === 'break'} onClick={() => timer.mode !== 'break' && timer.changeMode('break')}><Coffee size={17}/> Break</button>
      </div>
      <div className="timer-ring" style={{ background: `conic-gradient(var(--accent) ${elapsed * 100}%, var(--soft) 0)` }}>
        <div className="timer-face">
          <span className="timer-mode">{modes[timer.mode].label} session</span>
          <span className="timer-digits" role="timer">{minutes}:{seconds}</span>
        </div>
      </div>
      <p className="timer-status" role="status">{complete ? 'Session complete.' : timer.running ? 'Timer running' : timer.remaining < modes[timer.mode].seconds ? 'Paused' : 'Ready to start'}</p>
      <div className="timer-actions">
        <button className="primary" onClick={timer.toggle}>{timer.running ? <Pause size={17}/> : <Play size={17}/>} {timer.running ? 'Pause' : complete ? 'Start again' : timer.remaining === modes[timer.mode].seconds ? 'Start' : 'Resume'}</button>
        <button className="secondary" onClick={() => timer.changeMode(timer.mode)}><RotateCcw size={17}/> Reset</button>
      </div>
    </section>
    <aside className="focus-summary card">
      <span className="card-icon"><Timer size={20}/></span>
      <h2>Study sessions today</h2>
      <p className="focus-count">{timer.completed}</p>
      <p className="muted">Study for 25 minutes, then take a 5-minute break.</p>
    </aside>
  </div>;
}
