export const priorities = ['high', 'normal', 'low'] as const;
export type Priority = typeof priorities[number];
export const priorityLabels: Record<Priority, string> = { high: 'High', normal: 'Normal', low: 'Low' };

export type Entry = {
  id: string;
  kind: 'class' | 'task';
  title: string;
  subject: string;
  date: string;
  time: string;
  end: string;
  location: string;
  done: boolean;
  sample?: boolean;
  priority?: Priority;
};

export type Planner = { entries: Entry[]; started: boolean };
export type SubjectStats = { key: string; label: string; total: number; completed: number; overdue: number };
const storageKey = 'dayline.planner.v1';

export function dateKey(date: Date): string {
  return [date.getFullYear(), date.getMonth() + 1, date.getDate()].map(n => String(n).padStart(2, '0')).join('-');
}

export function fromKey(key: string): Date {
  const [year, month, day] = key.split('-').map(Number);
  return new Date(year, month - 1, day, 12);
}

export function shift(key: string, days: number): string {
  const date = fromKey(key);
  date.setDate(date.getDate() + days);
  return dateKey(date);
}

export function weekStart(key: string): string {
  return shift(key, -((fromKey(key).getDay() + 6) % 7));
}

export function formatDate(key: string, options: Intl.DateTimeFormatOptions): string {
  return fromKey(key).toLocaleDateString('en-US', options);
}

export const shortDate = (key: string) => formatDate(key, { month: 'short', day: 'numeric' });
export const stamp = (entry: Entry) => `${entry.date}T${entry.time}`;
export const chronological = (a: Entry, b: Entry) => stamp(a).localeCompare(stamp(b));
export const isOverdue = (entry: Entry, now: Date) => !entry.done && new Date(stamp(entry)) < now;
export const priorityOf = (entry: Entry) => entry.priority ?? 'normal';

export function subjectKey(subject: string) {
  return subject.trim().toLowerCase();
}

export function summarizeSubjects(tasks: Entry[], now: Date): SubjectStats[] {
  const bySubject = new Map<string, SubjectStats>();
  for (const task of tasks) {
    const key = subjectKey(task.subject);
    const row = bySubject.get(key) ?? {
      key, label: task.subject.trim() || 'No subject', total: 0, completed: 0, overdue: 0,
    };
    row.total++;
    if (task.done) row.completed++;
    else if (isOverdue(task, now)) row.overdue++;
    bySubject.set(key, row);
  }
  return [...bySubject.values()].sort((a, b) => Number(!a.key) - Number(!b.key) || a.label.localeCompare(b.label));
}

export function blank(date: string, kind: Entry['kind'] = 'task'): Entry {
  return { id: '', kind, title: '', subject: '', date, time: kind === 'task' ? '23:59' : '09:00', end: '10:00', location: '', done: false };
}

export function sampleEntries(today: string): Entry[] {
  const sample = (id: number, days: number, kind: Entry['kind'], title: string, subject: string, time: string, end = '', location = '') =>
    ({ ...blank(shift(today, days), kind), id: `sample-${id}`, title, subject, time, end, location, sample: true });
  return [
    sample(1, 0, 'class', 'Discrete Mathematics', 'MATH 102', '09:00', '10:15', 'Room B204'),
    sample(2, 0, 'class', 'Introduction to Computing', 'INF 106', '11:00', '12:15', 'Lab C310'),
    sample(3, 0, 'class', 'Academic Writing', 'ENG 101', '14:00', '15:15', 'Room A108'),
    { ...sample(4, 0, 'task', 'Submit problem set 04', 'MATH 102', '23:59'), priority: 'high' },
    sample(5, 1, 'task', 'Sketch app wireframes', 'INF 106', '17:00'),
    sample(6, 3, 'task', 'Reading response', 'ENG 101', '18:00'),
    sample(7, 3, 'class', 'Programming workshop', 'INF 106', '10:30', '11:45', 'Lab C310'),
    sample(8, 5, 'class', 'Discrete Mathematics', 'MATH 102', '09:00', '10:15', 'Room B204'),
  ];
}

export function loadPlanner(): Planner {
  try {
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      const parsed = JSON.parse(saved) as Planner;
      if (Array.isArray(parsed.entries) && typeof parsed.started === 'boolean') return parsed;
    }
  } catch {
    // The first write surfaces storage access errors without losing the in-memory planner.
  }
  return { entries: sampleEntries(dateKey(new Date())), started: false };
}

export function savePlanner(planner: Planner) {
  localStorage.setItem(storageKey, JSON.stringify(planner));
}
