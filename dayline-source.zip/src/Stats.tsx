import { ChartNoAxesColumn } from 'lucide-react';
import { summarizeSubjects, type Entry, type SubjectStats } from './planner';

export type SubjectFilter = Pick<SubjectStats, 'key' | 'label'>;

export function Stats({ tasks, now, showTasks }: {
  tasks: Entry[];
  now: Date;
  showTasks: (subject: SubjectFilter) => void;
}) {
  const rows = summarizeSubjects(tasks, now);
  if (!rows.length) {
    return <section className="card empty">
      <ChartNoAxesColumn size={25}/>
      <strong>No task statistics yet</strong>
      <span>Add a task to track progress by subject.</span>
    </section>;
  }

  const completed = rows.reduce((sum, row) => sum + row.completed, 0);
  const overdue = rows.reduce((sum, row) => sum + row.overdue, 0);

  return <div className="stats-layout">
    <dl className="stats-totals" aria-label="Overall task totals">
      <div className="card"><dt>Total tasks</dt><dd>{tasks.length}</dd></div>
      <div className="card stats-completed"><dt>Completed</dt><dd>{completed}</dd></div>
      <div className="card"><dt>Upcoming</dt><dd>{tasks.length - completed - overdue}</dd></div>
      <div className="card stats-overdue"><dt>Overdue</dt><dd>{overdue}</dd></div>
    </dl>
    <section className="card" aria-labelledby="subject-stats-title">
      <div className="section-head"><h2 id="subject-stats-title">By subject</h2><span className="card-icon"><ChartNoAxesColumn size={19}/></span></div>
      <ul className="subject-stats" role="list">
        {rows.map(row => {
          const percent = Math.round(row.completed / row.total * 100);
          return <li key={row.key}>
            <div className="stats-row-head">
              <h3>{row.label}</h3>
              <button className="text-button" aria-label={row.key ? `View ${row.label} tasks` : 'View tasks without a subject'} onClick={() => showTasks(row)}>View tasks</button>
            </div>
            <div className="subject-progress">
              <progress value={row.completed} max={row.total} aria-label={`${row.label} completion`}/>
              <span>{percent}%</span>
            </div>
            <p className="stats-counts">
              <span>{row.completed} of {row.total} completed</span>
              <span>{row.total - row.completed - row.overdue} upcoming</span>
              <span className={row.overdue ? 'stats-overdue' : undefined}>{row.overdue} overdue</span>
            </p>
          </li>;
        })}
      </ul>
    </section>
  </div>;
}
