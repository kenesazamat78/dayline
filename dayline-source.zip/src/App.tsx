import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowUpRight, BookOpen, CalendarDays, CalendarRange, ChartNoAxesColumn, Check, ChevronDown, ChevronLeft, ChevronRight, CircleCheck, Clock3, Flag, ListTodo, MapPin, Plus, Search, Timer, X } from 'lucide-react';
import { Focus, useFocusTimer } from './Focus';
import { Stats, type SubjectFilter } from './Stats';
import { blank, chronological, dateKey, formatDate, isOverdue, loadPlanner, priorities, priorityLabels, priorityOf, savePlanner, shift, shortDate, stamp, subjectKey, weekStart, type Entry, type Planner, type Priority } from './planner';

const tabs = [
  { label: 'Today', icon: CalendarDays },
  { label: 'Week', icon: CalendarRange },
  { label: 'Tasks', icon: ListTodo },
  { label: 'Stats', icon: ChartNoAxesColumn },
  { label: 'Focus', icon: Timer },
] as const;
type Tab = typeof tabs[number]['label'];
const filters = ['All', 'Open', 'Completed', 'Overdue'] as const;
type Filter = typeof filters[number];

function Subject({ entry }: { entry: Entry }) {
  const tone = entry.subject ? [...entry.subject].reduce((sum, char) => sum + char.charCodeAt(0), 0) % 3 : 0;
  return <span className={`subject tone-${tone}`}>{entry.subject || (entry.kind === 'task' ? 'Task' : 'Class')}</span>;
}

function PriorityTag({ entry }: { entry: Entry }) {
  const priority = priorityOf(entry);
  if (entry.kind !== 'task' || priority === 'normal') return null;
  return <span className={`priority priority-${priority}`}><Flag size={12}/> {priorityLabels[priority]} priority</span>;
}

function Timeline({ entries, edit }: { entries: Entry[]; edit: (entry: Entry) => void }) {
  if (!entries.length) return <div className="empty"><CalendarDays size={24}/><strong>No entries for this day</strong><span>Add a class or task to start planning.</span></div>;
  return <ol className="timeline">{entries.map(entry => <li key={entry.id}>
    <div className="time"><time dateTime={stamp(entry)}>{entry.time}</time>{entry.kind === 'class' && <span>{entry.end}</span>}</div>
    <span className={`node ${entry.kind}`}/>
    <button className="timeline-entry" onClick={() => edit(entry)}>
      <span className={`entry-title ${entry.done ? 'done' : ''}`}>{entry.title}</span>
      <span className="entry-meta">
        <Subject entry={entry}/>
        {entry.kind === 'class' && entry.location && <span><MapPin size={13}/>{entry.location}</span>}
        {entry.kind === 'task' && <><span>{entry.done ? 'Completed' : 'Due'}</span><PriorityTag entry={entry}/></>}
      </span>
    </button>
  </li>)}</ol>;
}

function Editor({ entry, close, save, remove }: { entry: Entry; close: () => void; save: (entry: Entry) => void; remove: (id: string) => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [draft, setDraft] = useState(entry);
  const [error, setError] = useState('');
  const [confirm, setConfirm] = useState(false);
  useEffect(() => { dialog.current?.showModal(); }, []);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const title = draft.title.trim();
    if (!title) return setError('Enter a title.');
    if (!draft.date || !draft.time) return setError('Choose a date and time.');
    if (draft.kind === 'class' && (!draft.end || draft.end <= draft.time)) return setError('End time must be after the start time.');
    save({ ...draft, title, subject: draft.subject.trim(), location: draft.location.trim(), id: draft.id || crypto.randomUUID() });
  }

  return <dialog ref={dialog} aria-labelledby="editor-title" onClose={close} onClick={event => { if (event.target === event.currentTarget) close(); }}>
    <div className="dialog-body">
      <div className="section-head"><h2 id="editor-title">{confirm ? 'Delete this entry?' : entry.id ? 'Edit entry' : 'Add entry'}</h2><button type="button" className="icon-button" onClick={close} aria-label="Close editor"><X size={20}/></button></div>
      {confirm ? <><p className="delete-title">{entry.title}</p><div className="form-actions">
        <button className="secondary" onClick={() => setConfirm(false)}>Keep entry</button>
        <button className="danger" onClick={() => remove(entry.id)}>Delete entry</button>
      </div></> : <form noValidate onSubmit={submit}>
        {!entry.id && <div className="segmented" aria-label="Entry type">{(['task', 'class'] as const).map(kind => <button type="button" key={kind} aria-pressed={draft.kind === kind} onClick={() => {
          setDraft({ ...draft, kind, time: blank(draft.date, kind).time });
          setError('');
        }}>{kind === 'task' ? 'Task' : 'Class'}</button>)}</div>}
        <label>Title<input autoFocus required value={draft.title} onChange={event => setDraft({ ...draft, title: event.target.value })} placeholder={draft.kind === 'task' ? 'e.g. Submit lab report' : 'e.g. Introduction to Computing'}/></label>
        <label>Subject <span>(optional)</span><input value={draft.subject} onChange={event => setDraft({ ...draft, subject: event.target.value })} placeholder="e.g. INF 106"/></label>
        <div className="form-grid">
          <label>Date<input required type="date" value={draft.date} onChange={event => setDraft({ ...draft, date: event.target.value })}/></label>
          <label>{draft.kind === 'task' ? 'Due time' : 'Start time'}<input required type="time" value={draft.time} onChange={event => setDraft({ ...draft, time: event.target.value })}/></label>
        </div>
        {draft.kind === 'task' && <div><label htmlFor="entry-priority">Priority</label>
          <span className="select-field"><select id="entry-priority" value={priorityOf(draft)} onChange={event => setDraft({ ...draft, priority: event.target.value as Priority })}>
            {priorities.map(priority => <option key={priority} value={priority}>{priorityLabels[priority]}</option>)}
          </select><ChevronDown size={16}/></span>
        </div>}
        {draft.kind === 'class' && <div className="form-grid">
          <label>End time<input required type="time" value={draft.end} onChange={event => setDraft({ ...draft, end: event.target.value })}/></label>
          <label>Location <span>(optional)</span><input value={draft.location} onChange={event => setDraft({ ...draft, location: event.target.value })}/></label>
        </div>}
        {error && <p className="error" role="alert">{error}</p>}
        <div className="form-actions">{entry.id && <button type="button" className="delete-link" onClick={() => setConfirm(true)}>Delete</button>}<button className="primary" type="submit">Save {draft.kind}</button></div>
      </form>}
    </div>
  </dialog>;
}

export function App() {
  const [planner, setPlanner] = useState(loadPlanner);
  const [tab, setTab] = useState<Tab>('Today');
  const [now, setNow] = useState(() => new Date());
  const today = dateKey(now);
  const focusTimer = useFocusTimer(today);
  const [selected, setSelected] = useState(today);
  const [filter, setFilter] = useState<Filter>('All');
  const [query, setQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<Priority | 'any'>('any');
  const [subjectFilter, setSubjectFilter] = useState<SubjectFilter | null>(null);
  const [taskOrder, setTaskOrder] = useState('deadline');
  const [draft, setDraft] = useState<Entry | null>(null);
  const [storageError, setStorageError] = useState(false);
  const [notice, setNotice] = useState('');
  const entries = [...planner.entries].sort(chronological);
  const tasks = entries.filter(entry => entry.kind === 'task');
  const todayEntries = entries.filter(entry => entry.date === today);
  const next = entries.find(entry => !entry.done && new Date(stamp(entry)) >= now);
  const deadlines = tasks.filter(entry => !entry.done);
  const upcoming = deadlines.filter(entry => !isOverdue(entry, now));
  const shownDeadlines = upcoming.length ? upcoming.slice(0, 3) : deadlines.slice(0, 3);
  const monday = weekStart(today);
  const sunday = shift(monday, 6);
  const weekTasks = tasks.filter(task => task.date >= monday && task.date <= sunday);
  const weekDone = weekTasks.filter(task => task.done).length;
  const start = weekStart(selected);
  const days = Array.from({ length: 7 }, (_, index) => shift(start, index));
  const search = query.trim().toLowerCase();
  const visibleTasks = tasks.filter(task => {
    const matchesStatus = filter === 'All' || (filter === 'Open' && !task.done) ||
      (filter === 'Completed' && task.done) || (filter === 'Overdue' && isOverdue(task, now));
    const matchesPriority = priorityFilter === 'any' || priorityOf(task) === priorityFilter;
    const matchesSubject = !subjectFilter || subjectKey(task.subject) === subjectFilter.key;
    return matchesStatus && matchesPriority && matchesSubject && `${task.title} ${task.subject}`.toLowerCase().includes(search);
  });
  if (taskOrder === 'priority') {
    visibleTasks.sort((a, b) => priorities.indexOf(priorityOf(a)) - priorities.indexOf(priorityOf(b)) || chronological(a, b));
  }

  useEffect(() => {
    const tick = () => setNow(new Date());
    const timer = window.setInterval(tick, 15_000);
    function sync(event: StorageEvent) {
      if (event.key === 'dayline.planner.v1' || event.key === null) setPlanner(loadPlanner());
    }
    window.addEventListener('focus', tick);
    window.addEventListener('storage', sync);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('focus', tick);
      window.removeEventListener('storage', sync);
    };
  }, []);

  function persist(nextPlanner: Planner) {
    try {
      savePlanner(nextPlanner);
      setStorageError(false);
    } catch {
      setStorageError(true);
    }
  }

  useEffect(() => { persist(loadPlanner()); }, []);

  function update(nextPlanner: Planner, message: string) {
    persist(nextPlanner);
    setPlanner(nextPlanner);
    setNotice(message);
  }

  function save(entry: Entry) {
    const updated = planner.entries.some(item => item.id === entry.id)
      ? planner.entries.map(item => item.id === entry.id ? entry : item)
      : [...planner.entries, entry];
    update({ entries: updated, started: true }, 'Entry saved.');
    setDraft(null);
  }

  function remove(id: string) {
    update({ ...planner, entries: planner.entries.filter(entry => entry.id !== id) }, 'Entry deleted.');
    setDraft(null);
  }

  function showTasks(subject: SubjectFilter | null) {
    setFilter('All');
    setQuery('');
    setPriorityFilter('any');
    setSubjectFilter(subject);
    setTab('Tasks');
  }

  return <div className="planner-shell">
    <header className="header"><div className="header-inner">
      <div className="brand"><span className="brand-mark"><CalendarDays size={21} strokeWidth={2.1}/></span>Dayline</div>
      <button className="primary add-button" onClick={() => setDraft(blank(tab === 'Week' ? selected : today))}><Plus size={20}/><span>Add entry</span></button>
      <nav aria-label="Planner views">{tabs.map(({ label, icon: Icon }) => <button key={label} aria-current={tab === label ? 'page' : undefined} onClick={() => setTab(label)}><Icon size={19}/><span>{label}</span>{label === 'Focus' && focusTimer.running && <i className="running-dot" title="Timer running"/>}</button>)}</nav>
    </div></header>
    <main>
      {storageError && <p className="error" role="alert">Device storage is unavailable. Changes may disappear on reload.</p>}
      {tab === 'Today' && <>
        <div className="page-heading"><p className="eyebrow">{formatDate(today, { weekday: 'long', month: 'long', day: 'numeric' })}</p><h1>Today</h1></div>
        <div className="today-layout">
          <div className="today-main">
            <section className="next-card" aria-label="Next planned entry">
              <div><p className="next-label"><Clock3 size={16}/> Up next</p>
              <h2>{next?.title || 'You’re all caught up'}</h2>
              <p>{next ? [next.date !== today ? shortDate(next.date) : '', next.kind === 'task' ? `Due at ${next.time}` : `${next.time}–${next.end}`, next.subject, next.location].filter(Boolean).join(' · ') : 'Nothing else on your planner.'}</p></div>
              {next && <button className="next-action" onClick={() => setDraft(next)} aria-label="Open next entry"><ArrowUpRight size={23}/></button>}
            </section>
            <section className="schedule card" aria-label="Today's schedule">
              <div className="section-head schedule-head"><h2>Today’s schedule</h2><span className="muted">{todayEntries.length} {todayEntries.length === 1 ? 'entry' : 'entries'}</span></div>
              <Timeline entries={todayEntries} edit={setDraft}/>
            </section>
          </div>
          <div className="today-side">
            <section className="week-progress card" aria-label="Task progress this week">
              <div className="section-head"><h2>This week</h2><span className="card-icon"><CircleCheck size={19}/></span></div>
              <p className="progress-count"><strong>{weekDone}</strong><span> / {weekTasks.length}</span></p>
              <div className="progress-track" role="progressbar" aria-label="Tasks completed this week" aria-valuenow={weekDone} aria-valuemin={0} aria-valuemax={Math.max(1, weekTasks.length)} aria-valuetext={`${weekDone} of ${weekTasks.length} tasks completed`}><span style={{ width: weekTasks.length ? `${weekDone / weekTasks.length * 100}%` : '0%' }}/></div>
              <p className="muted">{weekTasks.length ? 'Tasks due this week' : 'No tasks due this week'}</p>
            </section>
            <aside className="deadlines card" aria-labelledby="deadlines-title">
              <div className="section-head"><h2 id="deadlines-title">Deadlines</h2><span className="card-icon"><ListTodo size={19}/></span></div>
              {shownDeadlines.length ? <ul>{shownDeadlines.map((task, index) => <li key={task.id}><button onClick={() => setDraft(task)}>
                <span className="deadline-date">{isOverdue(task, now) ? 'Overdue' : index === 0 ? 'Nearest deadline' : task.date === today ? 'Today' : shortDate(task.date)}</span>
                <strong>{task.title}</strong><span className="deadline-meta">{shortDate(task.date)} · {task.time}{task.subject ? ` · ${task.subject}` : ''}</span><PriorityTag entry={task}/>
              </button></li>)}</ul> : <p className="muted">No open deadlines.</p>}
              <button className="text-button" onClick={() => showTasks(null)}>View all tasks</button>
            </aside>
          </div>
        </div>
      </>}
      {tab === 'Week' && <>
        <div className="page-heading"><h1>Week</h1></div>
        <section className="week card" aria-label="Week planner">
          <div className="section-head week-head"><h2>{shortDate(start)} – {shortDate(days[6])}, {fromYear(days[6])}</h2><div className="week-controls">
            <button className="icon-button" onClick={() => setSelected(shift(selected, -7))} aria-label="Previous week"><ChevronLeft size={21}/></button>
            <button className="secondary" onClick={() => setSelected(today)}>This week</button>
            <button className="icon-button" onClick={() => setSelected(shift(selected, 7))} aria-label="Next week"><ChevronRight size={21}/></button>
          </div></div>
          <div className="week-grid">{days.map(day => {
            const onDay = entries.filter(entry => entry.date === day);
            return <div key={day} className="week-day">
              <button className="day-button" aria-pressed={selected === day} aria-current={day === today ? 'date' : undefined} aria-label={formatDate(day, { weekday: 'long', month: 'long', day: 'numeric' })} onClick={() => setSelected(day)}>
                <span>{formatDate(day, { weekday: 'short' })}</span><strong>{Number(day.slice(-2))}</strong>{onDay.length > 0 && <i/>}
              </button>
              <div className="week-entries">{onDay.map(entry => <button onClick={() => { setSelected(day); setDraft(entry); }} key={entry.id} className={`week-entry ${entry.kind}`}>
                <span>{entry.time} {entry.kind === 'task' ? '· Due' : ''}</span><strong className={entry.done ? 'done' : ''}>{entry.title}</strong>
              </button>)}</div>
            </div>;
          })}</div>
          <div className="week-agenda"><div className="section-head schedule-head"><h2>{formatDate(selected, { weekday: 'long', month: 'long', day: 'numeric' })}</h2></div><Timeline entries={entries.filter(entry => entry.date === selected)} edit={setDraft}/></div>
        </section>
      </>}
      {tab === 'Tasks' && <>
        <div className="page-heading"><h1>Tasks</h1><p>{deadlines.length} open {deadlines.length === 1 ? 'task' : 'tasks'} · {tasks.length - deadlines.length} completed</p></div>
        <section className="task-panel card" aria-label="Task list">
          <div className="task-tools">
            <div className="task-search"><Search size={18}/><input type="search" aria-label="Search tasks" placeholder="Search title or subject" value={query} onChange={event => setQuery(event.target.value)}/></div>
            <div className="select-field">
              <select aria-label="Filter by priority" value={priorityFilter} onChange={event => setPriorityFilter(event.target.value as Priority | 'any')}>
                <option value="any">All priorities</option>
                {priorities.map(priority => <option key={priority} value={priority}>{priorityLabels[priority]}</option>)}
              </select><ChevronDown size={16}/>
            </div>
            <div className="select-field">
              <select aria-label="Sort tasks" value={taskOrder} onChange={event => setTaskOrder(event.target.value)}>
                <option value="deadline">By deadline</option><option value="priority">By priority</option>
              </select><ChevronDown size={16}/>
            </div>
          </div>
          {subjectFilter && <button className="subject-filter" onClick={() => setSubjectFilter(null)} aria-label={`Clear ${subjectFilter.label} subject filter`}>
            <span>{subjectFilter.label}</span><X size={15}/>
          </button>}
          <div className="task-filters" aria-label="Task filters">{filters.map(item => <button key={item} aria-pressed={filter === item} onClick={() => setFilter(item)}>{item}</button>)}</div>
          {visibleTasks.length ? <ul className="task-list">{visibleTasks.map(task => <li key={task.id}>
            <button className="check-button" aria-label={task.done ? `Reopen ${task.title}` : `Complete ${task.title}`} aria-pressed={task.done} onClick={() => update({ ...planner, started: true, entries: planner.entries.map(entry => entry.id === task.id ? { ...entry, done: !entry.done } : entry) }, task.done ? 'Task reopened.' : 'Task completed.')}>{task.done && <Check size={15}/>}</button>
            <button className="task-details" onClick={() => setDraft(task)}><strong className={task.done ? 'done' : ''}>{task.title}</strong><span className="entry-meta"><Subject entry={task}/><span>{shortDate(task.date)} · {task.time}</span><PriorityTag entry={task}/>{isOverdue(task, now) && <span className="overdue">Overdue</span>}</span></button>
            <button className="icon-button edit-button" aria-label={`Edit ${task.title}`} onClick={() => setDraft(task)}><ChevronRight size={20}/></button>
          </li>)}</ul> : <div className="empty"><CircleCheck size={25}/><strong>{tasks.length ? 'No matching tasks' : 'No tasks yet'}</strong><span>{tasks.length ? 'Try a different search or filter.' : 'Add a task to keep track of its deadline.'}</span></div>}
        </section>
      </>}
      {tab === 'Stats' && <>
        <div className="page-heading"><h1>Stats</h1><p>Task progress by subject</p></div>
        <Stats tasks={tasks} now={now} showTasks={showTasks}/>
      </>}
      {tab === 'Focus' && <>
        <div className="page-heading"><h1>Focus</h1></div>
        <Focus timer={focusTimer}/>
      </>}
      {entries.some(entry => entry.sample) && <footer className="sample"><BookOpen size={16}/><span>Sample data</span><button className="text-button" onClick={() => update({ started: true, entries: planner.entries.filter(entry => !entry.sample) }, 'Sample entries removed.')}>{entries.every(entry => entry.sample) ? 'Start empty' : 'Remove samples'}</button></footer>}
      <span className="sr-only" role="status">{notice}</span>
    </main>
    {draft && <Editor entry={draft} close={() => setDraft(null)} save={save} remove={remove}/>}
  </div>;
}

function fromYear(key: string) {
  return key.slice(0, 4);
}
