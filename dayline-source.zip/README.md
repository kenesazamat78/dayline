# Dayline

Dayline is an installable student planner for classes, assignments, and deadlines.

- Today and Week show your schedule and upcoming deadlines.
- Tasks supports search, priority filters, and completion.
- Stats shows progress by subject.
- Focus includes a 25-minute study timer and a 5-minute break timer.

## Run locally

Use Node.js 24 and pnpm 11.

```sh
pnpm install --frozen-lockfile
pnpm dev
```

For a production build with offline support, run `pnpm build` followed by `pnpm preview`.

## Data

Tasks are stored in the browser on the device where they are entered. Dayline starts with sample entries and lets you remove them. A production build can run offline after the app has loaded successfully online.

## Publish with GitHub Pages

In the repository, choose **Settings → Pages → Source → GitHub Actions**. Run **Deploy Dayline to GitHub Pages** from **Actions**, or push to `main`.
