import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  server: { watch: { ignored: ['**/.qa/**', '**/.pnpm-store/**', '**/materials/**'] } },
  build: { assetsInlineLimit: 0 },
  plugins: [{
    name: 'dayline-offline',
    apply: 'build',
    generateBundle: { order: 'post', handler(_, bundle) {
      const hash = createHash('sha256');
      for (const asset of Object.values(bundle)) {
        hash.update(asset.fileName);
        hash.update(asset.type === 'chunk' ? asset.code : asset.source);
      }
      const publicFiles = ['manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'maskable-512.png'];
      for (const file of publicFiles) hash.update(readFileSync(new URL('./public/' + file, import.meta.url)));
      const files = ['index.html', ...publicFiles, ...Object.keys(bundle)];
      const worker = `
const scope = self.registration.scope;
const prefix = 'dayline:' + scope + ':';
const version = prefix + ${JSON.stringify(hash.digest('hex').slice(0, 16))};
const shell = new URL('index.html', scope).href;
const urls = new Set(${JSON.stringify(files)}.map(path => new URL(path, scope).href));
self.addEventListener('install', event => {
  event.waitUntil(caches.open(version).then(cache => cache.addAll([...urls])).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(
    keys.filter(key => key.startsWith(prefix) && key !== version).map(key => caches.delete(key))
  )).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || !request.url.startsWith(scope)) return;
  if (request.mode === 'navigate' || urls.has(request.url)) {
    const key = request.mode === 'navigate' ? shell : request;
    event.respondWith(caches.open(version).then(cache => cache.match(key, { ignoreVary: true }))
      .then(response => response || fetch(request)));
  }
});
`;
      this.emitFile({ type: 'asset', fileName: 'sw.js', source: worker });
    } },
  }],
});
